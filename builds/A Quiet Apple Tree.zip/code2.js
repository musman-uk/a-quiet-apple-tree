gdjs.About_32SceneCode = {};
gdjs.About_32SceneCode.localVariables = [];
gdjs.About_32SceneCode.idToCallbackMap = new Map();
gdjs.About_32SceneCode.GDAbout_9595Description_9595TextObjects1= [];
gdjs.About_32SceneCode.GDAbout_9595Description_9595TextObjects2= [];
gdjs.About_32SceneCode.GDAbout_9595Return_9595Button_9595TextObjects1= [];
gdjs.About_32SceneCode.GDAbout_9595Return_9595Button_9595TextObjects2= [];
gdjs.About_32SceneCode.GDAbout_9595Title_9595TextObjects1= [];
gdjs.About_32SceneCode.GDAbout_9595Title_9595TextObjects2= [];
gdjs.About_32SceneCode.GDAbout_9595Signature_9595TextObjects1= [];
gdjs.About_32SceneCode.GDAbout_9595Signature_9595TextObjects2= [];
gdjs.About_32SceneCode.GDAbout_9595License_9595TextObjects1= [];
gdjs.About_32SceneCode.GDAbout_9595License_9595TextObjects2= [];


gdjs.About_32SceneCode.mapOfGDgdjs_9546About_959532SceneCode_9546GDAbout_95959595Return_95959595Button_95959595TextObjects1Objects = Hashtable.newFrom({"About_Return_Button_Text": gdjs.About_32SceneCode.GDAbout_9595Return_9595Button_9595TextObjects1});
gdjs.About_32SceneCode.mapOfGDgdjs_9546About_959532SceneCode_9546GDAbout_95959595Signature_95959595TextObjects1Objects = Hashtable.newFrom({"About_Signature_Text": gdjs.About_32SceneCode.GDAbout_9595Signature_9595TextObjects1});
gdjs.About_32SceneCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("About_Return_Button_Text"), gdjs.About_32SceneCode.GDAbout_9595Return_9595Button_9595TextObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.About_32SceneCode.mapOfGDgdjs_9546About_959532SceneCode_9546GDAbout_95959595Return_95959595Button_95959595TextObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Main Menu", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("About_Signature_Text"), gdjs.About_32SceneCode.GDAbout_9595Signature_9595TextObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.About_32SceneCode.mapOfGDgdjs_9546About_959532SceneCode_9546GDAbout_95959595Signature_95959595TextObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() == 0);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("https://github.com/musman-uk", runtimeScene);
}
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(1);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("About_Return_Button_Text"), gdjs.About_32SceneCode.GDAbout_9595Return_9595Button_9595TextObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.About_32SceneCode.GDAbout_9595Return_9595Button_9595TextObjects1.length;i<l;++i) {
    if ( gdjs.About_32SceneCode.GDAbout_9595Return_9595Button_9595TextObjects1[i].getBehavior("ButtonFSM").IsHovered(null) ) {
        isConditionTrue_0 = true;
        gdjs.About_32SceneCode.GDAbout_9595Return_9595Button_9595TextObjects1[k] = gdjs.About_32SceneCode.GDAbout_9595Return_9595Button_9595TextObjects1[i];
        ++k;
    }
}
gdjs.About_32SceneCode.GDAbout_9595Return_9595Button_9595TextObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.About_32SceneCode.GDAbout_9595Return_9595Button_9595TextObjects1 */
{for(var i = 0, len = gdjs.About_32SceneCode.GDAbout_9595Return_9595Button_9595TextObjects1.length ;i < len;++i) {
    gdjs.About_32SceneCode.GDAbout_9595Return_9595Button_9595TextObjects1[i].setColor("50;150;250");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("About_Return_Button_Text"), gdjs.About_32SceneCode.GDAbout_9595Return_9595Button_9595TextObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.About_32SceneCode.GDAbout_9595Return_9595Button_9595TextObjects1.length;i<l;++i) {
    if ( gdjs.About_32SceneCode.GDAbout_9595Return_9595Button_9595TextObjects1[i].getBehavior("ButtonFSM").IsIdle(null) ) {
        isConditionTrue_0 = true;
        gdjs.About_32SceneCode.GDAbout_9595Return_9595Button_9595TextObjects1[k] = gdjs.About_32SceneCode.GDAbout_9595Return_9595Button_9595TextObjects1[i];
        ++k;
    }
}
gdjs.About_32SceneCode.GDAbout_9595Return_9595Button_9595TextObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.About_32SceneCode.GDAbout_9595Return_9595Button_9595TextObjects1 */
{for(var i = 0, len = gdjs.About_32SceneCode.GDAbout_9595Return_9595Button_9595TextObjects1.length ;i < len;++i) {
    gdjs.About_32SceneCode.GDAbout_9595Return_9595Button_9595TextObjects1[i].setColor("0;100;200");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("About_Signature_Text"), gdjs.About_32SceneCode.GDAbout_9595Signature_9595TextObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.About_32SceneCode.GDAbout_9595Signature_9595TextObjects1.length;i<l;++i) {
    if ( gdjs.About_32SceneCode.GDAbout_9595Signature_9595TextObjects1[i].getBehavior("ButtonFSM").IsHovered(null) ) {
        isConditionTrue_0 = true;
        gdjs.About_32SceneCode.GDAbout_9595Signature_9595TextObjects1[k] = gdjs.About_32SceneCode.GDAbout_9595Signature_9595TextObjects1[i];
        ++k;
    }
}
gdjs.About_32SceneCode.GDAbout_9595Signature_9595TextObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.About_32SceneCode.GDAbout_9595Signature_9595TextObjects1 */
{for(var i = 0, len = gdjs.About_32SceneCode.GDAbout_9595Signature_9595TextObjects1.length ;i < len;++i) {
    gdjs.About_32SceneCode.GDAbout_9595Signature_9595TextObjects1[i].setColor("180;120;80");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("About_Signature_Text"), gdjs.About_32SceneCode.GDAbout_9595Signature_9595TextObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.About_32SceneCode.GDAbout_9595Signature_9595TextObjects1.length;i<l;++i) {
    if ( gdjs.About_32SceneCode.GDAbout_9595Signature_9595TextObjects1[i].getBehavior("ButtonFSM").IsIdle(null) ) {
        isConditionTrue_0 = true;
        gdjs.About_32SceneCode.GDAbout_9595Signature_9595TextObjects1[k] = gdjs.About_32SceneCode.GDAbout_9595Signature_9595TextObjects1[i];
        ++k;
    }
}
gdjs.About_32SceneCode.GDAbout_9595Signature_9595TextObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.About_32SceneCode.GDAbout_9595Signature_9595TextObjects1 */
{for(var i = 0, len = gdjs.About_32SceneCode.GDAbout_9595Signature_9595TextObjects1.length ;i < len;++i) {
    gdjs.About_32SceneCode.GDAbout_9595Signature_9595TextObjects1[i].setColor("139;87;42");
}
}
}

}


};

gdjs.About_32SceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.About_32SceneCode.GDAbout_9595Description_9595TextObjects1.length = 0;
gdjs.About_32SceneCode.GDAbout_9595Description_9595TextObjects2.length = 0;
gdjs.About_32SceneCode.GDAbout_9595Return_9595Button_9595TextObjects1.length = 0;
gdjs.About_32SceneCode.GDAbout_9595Return_9595Button_9595TextObjects2.length = 0;
gdjs.About_32SceneCode.GDAbout_9595Title_9595TextObjects1.length = 0;
gdjs.About_32SceneCode.GDAbout_9595Title_9595TextObjects2.length = 0;
gdjs.About_32SceneCode.GDAbout_9595Signature_9595TextObjects1.length = 0;
gdjs.About_32SceneCode.GDAbout_9595Signature_9595TextObjects2.length = 0;
gdjs.About_32SceneCode.GDAbout_9595License_9595TextObjects1.length = 0;
gdjs.About_32SceneCode.GDAbout_9595License_9595TextObjects2.length = 0;

gdjs.About_32SceneCode.eventsList0(runtimeScene);
gdjs.About_32SceneCode.GDAbout_9595Description_9595TextObjects1.length = 0;
gdjs.About_32SceneCode.GDAbout_9595Description_9595TextObjects2.length = 0;
gdjs.About_32SceneCode.GDAbout_9595Return_9595Button_9595TextObjects1.length = 0;
gdjs.About_32SceneCode.GDAbout_9595Return_9595Button_9595TextObjects2.length = 0;
gdjs.About_32SceneCode.GDAbout_9595Title_9595TextObjects1.length = 0;
gdjs.About_32SceneCode.GDAbout_9595Title_9595TextObjects2.length = 0;
gdjs.About_32SceneCode.GDAbout_9595Signature_9595TextObjects1.length = 0;
gdjs.About_32SceneCode.GDAbout_9595Signature_9595TextObjects2.length = 0;
gdjs.About_32SceneCode.GDAbout_9595License_9595TextObjects1.length = 0;
gdjs.About_32SceneCode.GDAbout_9595License_9595TextObjects2.length = 0;


return;

}

gdjs['About_32SceneCode'] = gdjs.About_32SceneCode;
