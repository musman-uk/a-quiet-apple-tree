gdjs.Game_32SceneCode = {};
gdjs.Game_32SceneCode.localVariables = [];
gdjs.Game_32SceneCode.idToCallbackMap = new Map();
gdjs.Game_32SceneCode.GDBasketObjects1_1final = [];

gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1_1final = [];

gdjs.Game_32SceneCode.GDGroundObjects1_1final = [];

gdjs.Game_32SceneCode.GDPondObjects1_1final = [];

gdjs.Game_32SceneCode.forEachIndex2 = 0;

gdjs.Game_32SceneCode.forEachObjects2 = [];

gdjs.Game_32SceneCode.forEachTemporary2 = null;

gdjs.Game_32SceneCode.forEachTotalCount2 = 0;

gdjs.Game_32SceneCode.GDGreen_9595Orchard_9595TreeObjects1= [];
gdjs.Game_32SceneCode.GDGreen_9595Orchard_9595TreeObjects2= [];
gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1= [];
gdjs.Game_32SceneCode.GDGreen_9595AppleObjects2= [];
gdjs.Game_32SceneCode.GDBasketObjects1= [];
gdjs.Game_32SceneCode.GDBasketObjects2= [];
gdjs.Game_32SceneCode.GDSunObjects1= [];
gdjs.Game_32SceneCode.GDSunObjects2= [];
gdjs.Game_32SceneCode.GDSkyObjects1= [];
gdjs.Game_32SceneCode.GDSkyObjects2= [];
gdjs.Game_32SceneCode.GDCloud_95951Objects1= [];
gdjs.Game_32SceneCode.GDCloud_95951Objects2= [];
gdjs.Game_32SceneCode.GDCloud_95953Objects1= [];
gdjs.Game_32SceneCode.GDCloud_95953Objects2= [];
gdjs.Game_32SceneCode.GDCloud_95952Objects1= [];
gdjs.Game_32SceneCode.GDCloud_95952Objects2= [];
gdjs.Game_32SceneCode.GDCloud_95954Objects1= [];
gdjs.Game_32SceneCode.GDCloud_95954Objects2= [];
gdjs.Game_32SceneCode.GDCloud_95955Objects1= [];
gdjs.Game_32SceneCode.GDCloud_95955Objects2= [];
gdjs.Game_32SceneCode.GDPondObjects1= [];
gdjs.Game_32SceneCode.GDPondObjects2= [];
gdjs.Game_32SceneCode.GDGroundObjects1= [];
gdjs.Game_32SceneCode.GDGroundObjects2= [];


gdjs.Game_32SceneCode.eventsList0 = function(runtimeScene) {

};gdjs.Game_32SceneCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Green_Apple"), gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1);

for (gdjs.Game_32SceneCode.forEachIndex2 = 0;gdjs.Game_32SceneCode.forEachIndex2 < gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1.length;++gdjs.Game_32SceneCode.forEachIndex2) {
gdjs.Game_32SceneCode.GDGreen_9595AppleObjects2.length = 0;


gdjs.Game_32SceneCode.forEachTemporary2 = gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[gdjs.Game_32SceneCode.forEachIndex2];
gdjs.Game_32SceneCode.GDGreen_9595AppleObjects2.push(gdjs.Game_32SceneCode.forEachTemporary2);
let isConditionTrue_0 = false;
if (true) {
{for(var i = 0, len = gdjs.Game_32SceneCode.GDGreen_9595AppleObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDGreen_9595AppleObjects2[i].returnVariable(gdjs.Game_32SceneCode.GDGreen_9595AppleObjects2[i].getVariables().getFromIndex(0)).setNumber(0);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDGreen_9595AppleObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDGreen_9595AppleObjects2[i].returnVariable(gdjs.Game_32SceneCode.GDGreen_9595AppleObjects2[i].getVariables().getFromIndex(1)).setNumber(0);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDGreen_9595AppleObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDGreen_9595AppleObjects2[i].returnVariable(gdjs.Game_32SceneCode.GDGreen_9595AppleObjects2[i].getVariables().getFromIndex(2)).setNumber(0);
}
}
}
}

}


};gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDGreen_95959595AppleObjects1Objects = Hashtable.newFrom({"Green_Apple": gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDGreen_95959595AppleObjects2Objects = Hashtable.newFrom({"Green_Apple": gdjs.Game_32SceneCode.GDGreen_9595AppleObjects2});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPondObjects2Objects = Hashtable.newFrom({"Pond": gdjs.Game_32SceneCode.GDPondObjects2});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDGreen_95959595AppleObjects2Objects = Hashtable.newFrom({"Green_Apple": gdjs.Game_32SceneCode.GDGreen_9595AppleObjects2});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDGroundObjects2Objects = Hashtable.newFrom({"Ground": gdjs.Game_32SceneCode.GDGroundObjects2});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDGreen_95959595AppleObjects2Objects = Hashtable.newFrom({"Green_Apple": gdjs.Game_32SceneCode.GDGreen_9595AppleObjects2});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDBasketObjects2Objects = Hashtable.newFrom({"Basket": gdjs.Game_32SceneCode.GDBasketObjects2});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDGreen_95959595AppleObjects1Objects = Hashtable.newFrom({"Green_Apple": gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPondObjects1Objects = Hashtable.newFrom({"Pond": gdjs.Game_32SceneCode.GDPondObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDGreen_95959595AppleObjects1Objects = Hashtable.newFrom({"Green_Apple": gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPondObjects1Objects = Hashtable.newFrom({"Pond": gdjs.Game_32SceneCode.GDPondObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDGreen_95959595AppleObjects1Objects = Hashtable.newFrom({"Green_Apple": gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDGroundObjects1Objects = Hashtable.newFrom({"Ground": gdjs.Game_32SceneCode.GDGroundObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDGreen_95959595AppleObjects1Objects = Hashtable.newFrom({"Green_Apple": gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDBasketObjects1Objects = Hashtable.newFrom({"Basket": gdjs.Game_32SceneCode.GDBasketObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDGreen_95959595AppleObjects1Objects = Hashtable.newFrom({"Green_Apple": gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDBasketObjects1Objects = Hashtable.newFrom({"Basket": gdjs.Game_32SceneCode.GDBasketObjects1});
gdjs.Game_32SceneCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "nature-background-noise.mp3", true, 20, 1);
}
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(0);
}
{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(gdjs.randomInRange(4, 6));
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "AppleDropTimer");
}

{ //Subevents
gdjs.Game_32SceneCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Green_Apple"), gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "AppleDropTimer") >= runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber();
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber() == 0);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[i].getVariableNumber(gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[k] = gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[i].getVariableNumber(gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[i].getVariables().getFromIndex(1)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[k] = gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickRandomObject(runtimeScene, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDGreen_95959595AppleObjects1Objects);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1 */
{for(var i = 0, len = gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[i].returnVariable(gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[i].getVariables().getFromIndex(0)).setNumber(1);
}
}
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(1);
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "AppleDropTimer");
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Green_Apple"), gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[i].getVariableNumber(gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[k] = gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1 */
{for(var i = 0, len = gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[i].setY(gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[i].getY() + (1));
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Green_Apple"), gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1);
gdjs.Game_32SceneCode.GDBasketObjects1.length = 0;

gdjs.Game_32SceneCode.GDGroundObjects1.length = 0;

gdjs.Game_32SceneCode.GDPondObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[i].getVariableNumber(gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[k] = gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.Game_32SceneCode.GDBasketObjects1_1final.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1_1final.length = 0;
gdjs.Game_32SceneCode.GDGroundObjects1_1final.length = 0;
gdjs.Game_32SceneCode.GDPondObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1, gdjs.Game_32SceneCode.GDGreen_9595AppleObjects2);

gdjs.copyArray(runtimeScene.getObjects("Pond"), gdjs.Game_32SceneCode.GDPondObjects2);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDGreen_95959595AppleObjects2Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPondObjects2Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDGreen_9595AppleObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1_1final.indexOf(gdjs.Game_32SceneCode.GDGreen_9595AppleObjects2[j]) === -1 )
            gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1_1final.push(gdjs.Game_32SceneCode.GDGreen_9595AppleObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDPondObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDPondObjects1_1final.indexOf(gdjs.Game_32SceneCode.GDPondObjects2[j]) === -1 )
            gdjs.Game_32SceneCode.GDPondObjects1_1final.push(gdjs.Game_32SceneCode.GDPondObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1, gdjs.Game_32SceneCode.GDGreen_9595AppleObjects2);

gdjs.copyArray(runtimeScene.getObjects("Ground"), gdjs.Game_32SceneCode.GDGroundObjects2);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDGreen_95959595AppleObjects2Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDGroundObjects2Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDGreen_9595AppleObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1_1final.indexOf(gdjs.Game_32SceneCode.GDGreen_9595AppleObjects2[j]) === -1 )
            gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1_1final.push(gdjs.Game_32SceneCode.GDGreen_9595AppleObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDGroundObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDGroundObjects1_1final.indexOf(gdjs.Game_32SceneCode.GDGroundObjects2[j]) === -1 )
            gdjs.Game_32SceneCode.GDGroundObjects1_1final.push(gdjs.Game_32SceneCode.GDGroundObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Basket"), gdjs.Game_32SceneCode.GDBasketObjects2);
gdjs.copyArray(gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1, gdjs.Game_32SceneCode.GDGreen_9595AppleObjects2);

isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDGreen_95959595AppleObjects2Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDBasketObjects2Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDBasketObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDBasketObjects1_1final.indexOf(gdjs.Game_32SceneCode.GDBasketObjects2[j]) === -1 )
            gdjs.Game_32SceneCode.GDBasketObjects1_1final.push(gdjs.Game_32SceneCode.GDBasketObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.Game_32SceneCode.GDGreen_9595AppleObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1_1final.indexOf(gdjs.Game_32SceneCode.GDGreen_9595AppleObjects2[j]) === -1 )
            gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1_1final.push(gdjs.Game_32SceneCode.GDGreen_9595AppleObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Game_32SceneCode.GDBasketObjects1_1final, gdjs.Game_32SceneCode.GDBasketObjects1);
gdjs.copyArray(gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1_1final, gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1);
gdjs.copyArray(gdjs.Game_32SceneCode.GDGroundObjects1_1final, gdjs.Game_32SceneCode.GDGroundObjects1);
gdjs.copyArray(gdjs.Game_32SceneCode.GDPondObjects1_1final, gdjs.Game_32SceneCode.GDPondObjects1);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1 */
{for(var i = 0, len = gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[i].returnVariable(gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[i].getVariables().getFromIndex(0)).setNumber(0);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[i].returnVariable(gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[i].getVariables().getFromIndex(1)).setNumber(1);
}
}
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(0);
}
{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(gdjs.randomInRange(5, 8));
}
{runtimeScene.getScene().getVariables().getFromIndex(0).add(1);
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "AppleDropTimer");
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Green_Apple"), gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1);
gdjs.copyArray(runtimeScene.getObjects("Pond"), gdjs.Game_32SceneCode.GDPondObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDGreen_95959595AppleObjects1Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPondObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDGreen_95959595AppleObjects1Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPondObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[i].getVariableNumber(gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[i].getVariables().getFromIndex(2)) == 0 ) {
        isConditionTrue_1 = true;
        gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[k] = gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{isConditionTrue_1 = runtimeScene.getOnceTriggers().triggerOnce(11502740);
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1 */
{for(var i = 0, len = gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[i].getBehavior("Opacity").setOpacity(110);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "pond_splash_noise.mp3", false, 45, 1);
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[i].returnVariable(gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[i].getVariables().getFromIndex(2)).setNumber(1);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Green_Apple"), gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1);
gdjs.copyArray(runtimeScene.getObjects("Ground"), gdjs.Game_32SceneCode.GDGroundObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDGreen_95959595AppleObjects1Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDGroundObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[i].getVariableNumber(gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[i].getVariables().getFromIndex(2)) == 0 ) {
        isConditionTrue_1 = true;
        gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[k] = gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{isConditionTrue_1 = runtimeScene.getOnceTriggers().triggerOnce(11504924);
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1 */
{gdjs.evtTools.sound.playSound(runtimeScene, "ground-impact-noise.mp3", false, 40, 1);
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[i].returnVariable(gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[i].getVariables().getFromIndex(2)).setNumber(1);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Basket"), gdjs.Game_32SceneCode.GDBasketObjects1);
gdjs.copyArray(runtimeScene.getObjects("Green_Apple"), gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDGreen_95959595AppleObjects1Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDBasketObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDGreen_95959595AppleObjects1Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDBasketObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[i].getVariableNumber(gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[i].getVariables().getFromIndex(2)) == 0 ) {
        isConditionTrue_1 = true;
        gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[k] = gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1 */
{runtimeScene.getGame().getVariables().getFromIndex(1).add(1);
}
{gdjs.evtTools.sound.playSound(runtimeScene, "basket-impact-noise.mp3", false, 40, 1);
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[i].returnVariable(gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[i].getVariables().getFromIndex(2)).setNumber(1);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() == 12);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11508740);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "EndGameTimer");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "EndGameTimer") >= 5;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "End Scene", false);
}
}

}


};

gdjs.Game_32SceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Game_32SceneCode.GDGreen_9595Orchard_9595TreeObjects1.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595Orchard_9595TreeObjects2.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595AppleObjects2.length = 0;
gdjs.Game_32SceneCode.GDBasketObjects1.length = 0;
gdjs.Game_32SceneCode.GDBasketObjects2.length = 0;
gdjs.Game_32SceneCode.GDSunObjects1.length = 0;
gdjs.Game_32SceneCode.GDSunObjects2.length = 0;
gdjs.Game_32SceneCode.GDSkyObjects1.length = 0;
gdjs.Game_32SceneCode.GDSkyObjects2.length = 0;
gdjs.Game_32SceneCode.GDCloud_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDCloud_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDCloud_95953Objects1.length = 0;
gdjs.Game_32SceneCode.GDCloud_95953Objects2.length = 0;
gdjs.Game_32SceneCode.GDCloud_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDCloud_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDCloud_95954Objects1.length = 0;
gdjs.Game_32SceneCode.GDCloud_95954Objects2.length = 0;
gdjs.Game_32SceneCode.GDCloud_95955Objects1.length = 0;
gdjs.Game_32SceneCode.GDCloud_95955Objects2.length = 0;
gdjs.Game_32SceneCode.GDPondObjects1.length = 0;
gdjs.Game_32SceneCode.GDPondObjects2.length = 0;
gdjs.Game_32SceneCode.GDGroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDGroundObjects2.length = 0;

gdjs.Game_32SceneCode.eventsList2(runtimeScene);
gdjs.Game_32SceneCode.GDGreen_9595Orchard_9595TreeObjects1.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595Orchard_9595TreeObjects2.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595AppleObjects1.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595AppleObjects2.length = 0;
gdjs.Game_32SceneCode.GDBasketObjects1.length = 0;
gdjs.Game_32SceneCode.GDBasketObjects2.length = 0;
gdjs.Game_32SceneCode.GDSunObjects1.length = 0;
gdjs.Game_32SceneCode.GDSunObjects2.length = 0;
gdjs.Game_32SceneCode.GDSkyObjects1.length = 0;
gdjs.Game_32SceneCode.GDSkyObjects2.length = 0;
gdjs.Game_32SceneCode.GDCloud_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDCloud_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDCloud_95953Objects1.length = 0;
gdjs.Game_32SceneCode.GDCloud_95953Objects2.length = 0;
gdjs.Game_32SceneCode.GDCloud_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDCloud_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDCloud_95954Objects1.length = 0;
gdjs.Game_32SceneCode.GDCloud_95954Objects2.length = 0;
gdjs.Game_32SceneCode.GDCloud_95955Objects1.length = 0;
gdjs.Game_32SceneCode.GDCloud_95955Objects2.length = 0;
gdjs.Game_32SceneCode.GDPondObjects1.length = 0;
gdjs.Game_32SceneCode.GDPondObjects2.length = 0;
gdjs.Game_32SceneCode.GDGroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDGroundObjects2.length = 0;


return;

}

gdjs['Game_32SceneCode'] = gdjs.Game_32SceneCode;
