gdjs.End_32SceneCode = {};
gdjs.End_32SceneCode.localVariables = [];
gdjs.End_32SceneCode.idToCallbackMap = new Map();
gdjs.End_32SceneCode.GDOutcome_9595TextObjects1= [];
gdjs.End_32SceneCode.GDOutcome_9595TextObjects2= [];
gdjs.End_32SceneCode.GDOutcome_9595TextObjects3= [];
gdjs.End_32SceneCode.GDEnd_9595Return_9595Button_9595TextObjects1= [];
gdjs.End_32SceneCode.GDEnd_9595Return_9595Button_9595TextObjects2= [];
gdjs.End_32SceneCode.GDEnd_9595Return_9595Button_9595TextObjects3= [];
gdjs.End_32SceneCode.GDParting_9595TextObjects1= [];
gdjs.End_32SceneCode.GDParting_9595TextObjects2= [];
gdjs.End_32SceneCode.GDParting_9595TextObjects3= [];


gdjs.End_32SceneCode.eventsList0 = function(runtimeScene) {
{

let elseEventsChainSatisfied = false;

{


elseEventsChainSatisfied = false;
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber() == 0);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Outcome_Text"), gdjs.End_32SceneCode.GDOutcome_9595TextObjects2);
{for(var i = 0, len = gdjs.End_32SceneCode.GDOutcome_9595TextObjects2.length ;i < len;++i) {
    gdjs.End_32SceneCode.GDOutcome_9595TextObjects2[i].getBehavior("Text").setText("Letting all the apples fall where ever they land...");
}
}
elseEventsChainSatisfied = true;
}

}


{


if (!elseEventsChainSatisfied) {
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber() == 1);
}
if (!elseEventsChainSatisfied && isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Outcome_Text"), gdjs.End_32SceneCode.GDOutcome_9595TextObjects2);
{for(var i = 0, len = gdjs.End_32SceneCode.GDOutcome_9595TextObjects2.length ;i < len;++i) {
    gdjs.End_32SceneCode.GDOutcome_9595TextObjects2[i].getBehavior("Text").setText("Know what they say, an apple a day....");
}
}
elseEventsChainSatisfied = true;
}
}

}


{


if (!elseEventsChainSatisfied) {
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
{isConditionTrue_1 = (runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber() > 1);
}
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{isConditionTrue_1 = (runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber() < 6);
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (!elseEventsChainSatisfied && isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Outcome_Text"), gdjs.End_32SceneCode.GDOutcome_9595TextObjects2);
{for(var i = 0, len = gdjs.End_32SceneCode.GDOutcome_9595TextObjects2.length ;i < len;++i) {
    gdjs.End_32SceneCode.GDOutcome_9595TextObjects2[i].getBehavior("Text").setText("More than enough apples to share...");
}
}
elseEventsChainSatisfied = true;
}
}

}


{


if (!elseEventsChainSatisfied) {
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
{isConditionTrue_1 = (runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber() > 6);
}
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{isConditionTrue_1 = (runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber() < runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber());
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (!elseEventsChainSatisfied && isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Outcome_Text"), gdjs.End_32SceneCode.GDOutcome_9595TextObjects2);
{for(var i = 0, len = gdjs.End_32SceneCode.GDOutcome_9595TextObjects2.length ;i < len;++i) {
    gdjs.End_32SceneCode.GDOutcome_9595TextObjects2[i].getBehavior("Text").setText("With this many apples you could make an apple pie, perhaps not from scratch...");
}
}
elseEventsChainSatisfied = true;
}
}

}


{


if (!elseEventsChainSatisfied) {
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber() == runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber());
}
if (!elseEventsChainSatisfied && isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Outcome_Text"), gdjs.End_32SceneCode.GDOutcome_9595TextObjects1);
{for(var i = 0, len = gdjs.End_32SceneCode.GDOutcome_9595TextObjects1.length ;i < len;++i) {
    gdjs.End_32SceneCode.GDOutcome_9595TextObjects1[i].getBehavior("Text").setText("Sometimes, you have got to catch all of the apples...");
}
}
elseEventsChainSatisfied = true;
}
}

}

}

};gdjs.End_32SceneCode.mapOfGDgdjs_9546End_959532SceneCode_9546GDEnd_95959595Return_95959595Button_95959595TextObjects1Objects = Hashtable.newFrom({"End_Return_Button_Text": gdjs.End_32SceneCode.GDEnd_9595Return_9595Button_9595TextObjects1});
gdjs.End_32SceneCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("End_Return_Button_Text"), gdjs.End_32SceneCode.GDEnd_9595Return_9595Button_9595TextObjects1);
{for(var i = 0, len = gdjs.End_32SceneCode.GDEnd_9595Return_9595Button_9595TextObjects1.length ;i < len;++i) {
    gdjs.End_32SceneCode.GDEnd_9595Return_9595Button_9595TextObjects1[i].hide();
}
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "EndSceneTimer");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "EndSceneTimer") >= 1.5;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11591180);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.End_32SceneCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "EndSceneTimer") > 6;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11597636);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Parting_Text"), gdjs.End_32SceneCode.GDParting_9595TextObjects1);
{for(var i = 0, len = gdjs.End_32SceneCode.GDParting_9595TextObjects1.length ;i < len;++i) {
    gdjs.End_32SceneCode.GDParting_9595TextObjects1[i].getBehavior("Text").setText("This tree is thankful for your company, as the quiet moment draws to a close for now...");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "EndSceneTimer") >= 10.5;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11598780);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("End_Return_Button_Text"), gdjs.End_32SceneCode.GDEnd_9595Return_9595Button_9595TextObjects1);
{for(var i = 0, len = gdjs.End_32SceneCode.GDEnd_9595Return_9595Button_9595TextObjects1.length ;i < len;++i) {
    gdjs.End_32SceneCode.GDEnd_9595Return_9595Button_9595TextObjects1[i].hide(false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("End_Return_Button_Text"), gdjs.End_32SceneCode.GDEnd_9595Return_9595Button_9595TextObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.End_32SceneCode.mapOfGDgdjs_9546End_959532SceneCode_9546GDEnd_95959595Return_95959595Button_95959595TextObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Main Menu", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("End_Return_Button_Text"), gdjs.End_32SceneCode.GDEnd_9595Return_9595Button_9595TextObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.End_32SceneCode.GDEnd_9595Return_9595Button_9595TextObjects1.length;i<l;++i) {
    if ( gdjs.End_32SceneCode.GDEnd_9595Return_9595Button_9595TextObjects1[i].getBehavior("ButtonFSM").IsIdle(null) ) {
        isConditionTrue_0 = true;
        gdjs.End_32SceneCode.GDEnd_9595Return_9595Button_9595TextObjects1[k] = gdjs.End_32SceneCode.GDEnd_9595Return_9595Button_9595TextObjects1[i];
        ++k;
    }
}
gdjs.End_32SceneCode.GDEnd_9595Return_9595Button_9595TextObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.End_32SceneCode.GDEnd_9595Return_9595Button_9595TextObjects1 */
{for(var i = 0, len = gdjs.End_32SceneCode.GDEnd_9595Return_9595Button_9595TextObjects1.length ;i < len;++i) {
    gdjs.End_32SceneCode.GDEnd_9595Return_9595Button_9595TextObjects1[i].setColor("0;100;200");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("End_Return_Button_Text"), gdjs.End_32SceneCode.GDEnd_9595Return_9595Button_9595TextObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.End_32SceneCode.GDEnd_9595Return_9595Button_9595TextObjects1.length;i<l;++i) {
    if ( gdjs.End_32SceneCode.GDEnd_9595Return_9595Button_9595TextObjects1[i].getBehavior("ButtonFSM").IsHovered(null) ) {
        isConditionTrue_0 = true;
        gdjs.End_32SceneCode.GDEnd_9595Return_9595Button_9595TextObjects1[k] = gdjs.End_32SceneCode.GDEnd_9595Return_9595Button_9595TextObjects1[i];
        ++k;
    }
}
gdjs.End_32SceneCode.GDEnd_9595Return_9595Button_9595TextObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.End_32SceneCode.GDEnd_9595Return_9595Button_9595TextObjects1 */
{for(var i = 0, len = gdjs.End_32SceneCode.GDEnd_9595Return_9595Button_9595TextObjects1.length ;i < len;++i) {
    gdjs.End_32SceneCode.GDEnd_9595Return_9595Button_9595TextObjects1[i].setColor("50;150;250");
}
}
}

}


};

gdjs.End_32SceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.End_32SceneCode.GDOutcome_9595TextObjects1.length = 0;
gdjs.End_32SceneCode.GDOutcome_9595TextObjects2.length = 0;
gdjs.End_32SceneCode.GDOutcome_9595TextObjects3.length = 0;
gdjs.End_32SceneCode.GDEnd_9595Return_9595Button_9595TextObjects1.length = 0;
gdjs.End_32SceneCode.GDEnd_9595Return_9595Button_9595TextObjects2.length = 0;
gdjs.End_32SceneCode.GDEnd_9595Return_9595Button_9595TextObjects3.length = 0;
gdjs.End_32SceneCode.GDParting_9595TextObjects1.length = 0;
gdjs.End_32SceneCode.GDParting_9595TextObjects2.length = 0;
gdjs.End_32SceneCode.GDParting_9595TextObjects3.length = 0;

gdjs.End_32SceneCode.eventsList1(runtimeScene);
gdjs.End_32SceneCode.GDOutcome_9595TextObjects1.length = 0;
gdjs.End_32SceneCode.GDOutcome_9595TextObjects2.length = 0;
gdjs.End_32SceneCode.GDOutcome_9595TextObjects3.length = 0;
gdjs.End_32SceneCode.GDEnd_9595Return_9595Button_9595TextObjects1.length = 0;
gdjs.End_32SceneCode.GDEnd_9595Return_9595Button_9595TextObjects2.length = 0;
gdjs.End_32SceneCode.GDEnd_9595Return_9595Button_9595TextObjects3.length = 0;
gdjs.End_32SceneCode.GDParting_9595TextObjects1.length = 0;
gdjs.End_32SceneCode.GDParting_9595TextObjects2.length = 0;
gdjs.End_32SceneCode.GDParting_9595TextObjects3.length = 0;


return;

}

gdjs['End_32SceneCode'] = gdjs.End_32SceneCode;
