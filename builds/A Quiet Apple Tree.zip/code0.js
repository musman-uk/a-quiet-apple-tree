gdjs.Main_32MenuCode = {};
gdjs.Main_32MenuCode.localVariables = [];
gdjs.Main_32MenuCode.idToCallbackMap = new Map();
gdjs.Main_32MenuCode.GDPlay_9595Button_9595TextObjects1= [];
gdjs.Main_32MenuCode.GDPlay_9595Button_9595TextObjects2= [];
gdjs.Main_32MenuCode.GDAbout_9595Button_9595TextObjects1= [];
gdjs.Main_32MenuCode.GDAbout_9595Button_9595TextObjects2= [];
gdjs.Main_32MenuCode.GDGame_9595Title_9595TextObjects1= [];
gdjs.Main_32MenuCode.GDGame_9595Title_9595TextObjects2= [];


gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDPlay_95959595Button_95959595TextObjects1Objects = Hashtable.newFrom({"Play_Button_Text": gdjs.Main_32MenuCode.GDPlay_9595Button_9595TextObjects1});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDAbout_95959595Button_95959595TextObjects1Objects = Hashtable.newFrom({"About_Button_Text": gdjs.Main_32MenuCode.GDAbout_9595Button_9595TextObjects1});
gdjs.Main_32MenuCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Play_Button_Text"), gdjs.Main_32MenuCode.GDPlay_9595Button_9595TextObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDPlay_95959595Button_95959595TextObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Game Scene", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("About_Button_Text"), gdjs.Main_32MenuCode.GDAbout_9595Button_9595TextObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDAbout_95959595Button_95959595TextObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "About Scene", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Play_Button_Text"), gdjs.Main_32MenuCode.GDPlay_9595Button_9595TextObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDPlay_9595Button_9595TextObjects1.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDPlay_9595Button_9595TextObjects1[i].getBehavior("ButtonFSM").IsHovered(null) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDPlay_9595Button_9595TextObjects1[k] = gdjs.Main_32MenuCode.GDPlay_9595Button_9595TextObjects1[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDPlay_9595Button_9595TextObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDPlay_9595Button_9595TextObjects1 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDPlay_9595Button_9595TextObjects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDPlay_9595Button_9595TextObjects1[i].setColor("50;150;250");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Play_Button_Text"), gdjs.Main_32MenuCode.GDPlay_9595Button_9595TextObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDPlay_9595Button_9595TextObjects1.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDPlay_9595Button_9595TextObjects1[i].getBehavior("ButtonFSM").IsIdle(null) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDPlay_9595Button_9595TextObjects1[k] = gdjs.Main_32MenuCode.GDPlay_9595Button_9595TextObjects1[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDPlay_9595Button_9595TextObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDPlay_9595Button_9595TextObjects1 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDPlay_9595Button_9595TextObjects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDPlay_9595Button_9595TextObjects1[i].setColor("0;100;200");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("About_Button_Text"), gdjs.Main_32MenuCode.GDAbout_9595Button_9595TextObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDAbout_9595Button_9595TextObjects1.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDAbout_9595Button_9595TextObjects1[i].getBehavior("ButtonFSM").IsHovered(null) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDAbout_9595Button_9595TextObjects1[k] = gdjs.Main_32MenuCode.GDAbout_9595Button_9595TextObjects1[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDAbout_9595Button_9595TextObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDAbout_9595Button_9595TextObjects1 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDAbout_9595Button_9595TextObjects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDAbout_9595Button_9595TextObjects1[i].setColor("50;150;250");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("About_Button_Text"), gdjs.Main_32MenuCode.GDAbout_9595Button_9595TextObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDAbout_9595Button_9595TextObjects1.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDAbout_9595Button_9595TextObjects1[i].getBehavior("ButtonFSM").IsIdle(null) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDAbout_9595Button_9595TextObjects1[k] = gdjs.Main_32MenuCode.GDAbout_9595Button_9595TextObjects1[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDAbout_9595Button_9595TextObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDAbout_9595Button_9595TextObjects1 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDAbout_9595Button_9595TextObjects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDAbout_9595Button_9595TextObjects1[i].setColor("0;100;200");
}
}
}

}


};

gdjs.Main_32MenuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Main_32MenuCode.GDPlay_9595Button_9595TextObjects1.length = 0;
gdjs.Main_32MenuCode.GDPlay_9595Button_9595TextObjects2.length = 0;
gdjs.Main_32MenuCode.GDAbout_9595Button_9595TextObjects1.length = 0;
gdjs.Main_32MenuCode.GDAbout_9595Button_9595TextObjects2.length = 0;
gdjs.Main_32MenuCode.GDGame_9595Title_9595TextObjects1.length = 0;
gdjs.Main_32MenuCode.GDGame_9595Title_9595TextObjects2.length = 0;

gdjs.Main_32MenuCode.eventsList0(runtimeScene);
gdjs.Main_32MenuCode.GDPlay_9595Button_9595TextObjects1.length = 0;
gdjs.Main_32MenuCode.GDPlay_9595Button_9595TextObjects2.length = 0;
gdjs.Main_32MenuCode.GDAbout_9595Button_9595TextObjects1.length = 0;
gdjs.Main_32MenuCode.GDAbout_9595Button_9595TextObjects2.length = 0;
gdjs.Main_32MenuCode.GDGame_9595Title_9595TextObjects1.length = 0;
gdjs.Main_32MenuCode.GDGame_9595Title_9595TextObjects2.length = 0;


return;

}

gdjs['Main_32MenuCode'] = gdjs.Main_32MenuCode;
